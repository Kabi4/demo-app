export { default as PrivateRoutes } from './PrivateRoutes';

export { default as AuthRoute } from './AuthRoutes';
