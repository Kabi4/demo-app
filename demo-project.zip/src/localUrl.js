export const local_url = 'https://stage.api.sloovi.com';
