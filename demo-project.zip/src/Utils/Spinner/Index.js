import React from 'react';
import './style.css';
const index = () => {
    return (
        <div className="spinner">
            <div className="loader"></div>
        </div>
    );
};

export default index;
