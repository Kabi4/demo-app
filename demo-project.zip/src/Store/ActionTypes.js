export const login = 'LOGIN';
export const logout = 'LOGOUT';
